<?php $__env->startSection('container'); ?>

  <div style="display:none;">

      <!-- Url  defoult-->
      <?php echo e($urlFunc = '/funcionarios'); ?>

      <?php echo e($srcFunc = ''); ?>

      <?php echo e($urlUser = '/users'); ?>


  </div>



<div class="clearfix"></div>
<div class="row">
  <div class="col-md-12 col-sm-12 col-xs-12">
    <div class="x_panel">

      <div class="x_title">
        <h2>Perfil do funcionario</h2>

        <div class="clearfix"></div>
      </div>

      <?php if(isset($data)): ?>

      <div class="x_content">

        <div class="col-md-3 col-sm-3 col-xs-12 profile_left">

          <div class="profile_img">

            <!-- end of image cropping -->
            <div id="crop-avatar">
              <!-- Current avatar -->

              <?php if($data->foto == 'user.png'): ?>
                <img class="img-responsive avatar-view" src="<?php echo e($srcFunc); ?>/images/profiles/<?php echo e($data->foto); ?>" alt="Avatar" title="Change the avatar">
              <?php else: ?>
                <img class="img-responsive avatar-view" src="<?php echo e($srcFunc); ?>/images/profiles/<?php echo e($data->id); ?>/<?php echo e($data->foto); ?>" alt="Avatar" title="Change the avatar">
              <?php endif; ?>

            </div>
            <!-- end of image cropping -->

          </div>



          <h3><?php echo e($data->name); ?></h3>

          <ul class="list-unstyled user_data">
            <li>
              <i class="fa fa-briefcase user-profile-icon"></i> <?php echo e($data->funcao); ?>

            </li>
          </ul>

          <button type="button" class="btn btn-default" data-toggle="modal" data-target=".bs-example-modal-sm-foto"><i class="fa fa-camera"></i> Editar Foto</button>
          <br />

        </div>

        <div class="col-md-6 col-sm-6 col-xs-12">

          <div class="table-responsive">
            <table class="table">
              <tbody>
                <tr>
                  <th style="width:20%">EMAIL:</th>
                  <td> <?php echo e($data->email); ?></td>
                </tr>
                <tr>
                  <th>CPF:</th>
                  <td> <?php echo e($data->cpf); ?></td>
                </tr>
                <tr>
                  <th>RG:</th>
                  <td> <?php echo e($data->rg); ?></td>
                </tr>
                <tr>
                  <th>Telefone:</th>
                  <td> <?php echo e($data->telefone_1); ?> / <?php echo e($data->telefone_2); ?></td>
                </tr>
                <tr>
                  <th>Endereço:</th>
                  <td>
                    <?php echo e($data->endereco); ?>, <?php echo e($data->numero); ?> - <?php echo e($data->complemento); ?> </br>
                    <?php echo e($data->bairro); ?> - <?php echo e($data->cidade); ?> - <?php echo e($data->uf); ?> CEP: <?php echo e($data->cep); ?>

                  </td>
                </tr>
                <tr>
                  <th>Idade:</th>
                  <td> <?php echo e($data->idade); ?></td>
                </tr>
                <tr>
                  <th>sexo:</th>
                  <td> <?php echo e($data->sexo); ?></td>
                </tr>
                <tr>
                  <th>Admição:</th>
                  <td> <?php echo e($data->data_admissao); ?></td>
                </tr>
                <tr>
                  <th>salario:</th>
                  <td> <?php echo e($data->salario); ?></td>
                </tr>

              </tbody>
            </table>
          </div>



          <?php if($data->user == null): ?>


              <button type="button" class="btn btn-default" data-toggle="modal" data-target=".bs-example-modal-sm-newUser">
                <i class="fa fa-users"></i>
                Criar um usuário no Sistema para este Funcionário
              </button>

          <?php elseif($data->user->status == 0): ?>


              <button type="button" class="btn btn-info" data-toggle="modal" data-target=".bs-example-modal-sm-onUser">
                <i class="fa fa-users"></i>
                Reativar o usuário deste Funcionário
              </button>

          <?php else: ?>


              <button type="button" class="btn btn-danger" data-toggle="modal" data-target=".bs-example-modal-sm-ofUser">
                <i class="fa fa-users"></i>
                Desativar o usuário deste Funcionário
              </button>

          <?php endif; ?>



        </div>

        <div class="col-md-3 col-sm-3 col-xs-12">

          <a class="btn btn-warning" href="<?php echo e($urlFunc); ?>/<?php echo e($data->id); ?>/edit"><i class="fa fa-edit m-right-xs"></i> Editar</a>
          <?php if($data->status == 1): ?>
            <button type="button" class="btn btn-danger" data-toggle="modal" data-target=".bs-example-modal-sm-excluir"><i class="glyphicon glyphicon-trash"></i> Excluir</button>
          <?php else: ?>
            <button type="button" class="btn btn-default" data-toggle="modal" data-target=".bs-example-modal-sm-excluir"><i class="glyphicon glyphicon-off"></i> Recuperar</button>

          <?php endif; ?>



        </div>

      </div>

    <?php endif; ?>

    </div>
  </div>
</div>



<!-- Modal edit Foto-->

<div class="modal fade bs-example-modal-sm-foto" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <form class="" action="<?php echo e($urlFunc); ?>/foto/<?php echo e($data->id); ?>" method="post" enctype="multipart/form-data">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span>
          </button>
          <h4 class="modal-title" id="myModalLabel2">Editar Foto</h4>
        </div>
        <div class="modal-body">


            <div class="form-group">
              <label for="foto">Foto</label>
              <input type="file" class="form-control" id="foto" name="foto" required>
            </div>



        </div>
        <div class="modal-footer">
            <input type="hidden" name="_method" value="put">
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Salvar</button>
        </div>
      </form>
    </div>
  </div>
</div>


<?php if($data->status == 1): ?>


<!-- Modal exclusão-->

<div class="modal fade bs-example-modal-sm-excluir" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">


        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span>
          </button>
          <h4 class="modal-title" id="myModalLabel2">Deletar Funcionário</h4>
        </div>

        <form action="<?php echo e($urlFunc); ?>/<?php echo e($data->id); ?>" method="POST">
        <div class="modal-body">

          Você deseja deletar o Funcionário <?php echo e($data->name); ?> ?

        </div>
        <div class="modal-footer">

          <input type="hidden" name="_method" value="delete">
          <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-danger">
            <i class="glyphicon glyphicon-trash"></i>
            Deletar
          </button>

        </div>

        </form>

    </div>
  </div>
</div>

<?php else: ?>


  <!-- Modal Recuperação-->

  <div class="modal fade bs-example-modal-sm-excluir" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-sm">
      <div class="modal-content">


          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span>
            </button>
            <h4 class="modal-title" id="myModalLabel2">Recuperar Funcionário</h4>
          </div>

          <form action="<?php echo e($urlFunc); ?>/<?php echo e($data->id); ?>" method="POST">
          <div class="modal-body">

            Você deseja Recuperar o Funcionário <?php echo e($data->name); ?> ?

          </div>
          <div class="modal-footer">

            <input type="hidden" name="_method" value="delete">
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-success">
              <i class="glyphicon glyphicon-off"></i>
              Recuperar
            </button>

          </div>

          </form>

      </div>
    </div>
  </div>

<?php endif; ?>

<!-- Modal Create usuario-->

<div class="modal fade bs-example-modal-sm-newUser" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">


        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span>
          </button>
          <h4 class="modal-title" id="myModalLabel2">Criar Usuário</h4>
        </div>

        <form action="<?php echo e($urlUser); ?>/newUser/<?php echo e($data->id); ?>" method="POST">
        <div class="modal-body">

          <div class="form-group">

            <h4>Autorização:</h4>
            <p>

              <input type="radio" class="flat" name="auth" id="admin" value="1" checked="" required /> <label for="admin">Administrador</label>
            </p>
            <p>

              <input type="radio" class="flat" name="auth" id="inst" value="2" /> <label for="inst">Instrutor:</label>
            </p>

          </div>

        </div>
        <div class="modal-footer">

          <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-success">

            Criar
          </button>

        </div>

        </form>

    </div>
  </div>
</div>


<?php if(isset($data->user->id)): ?>

<!-- Modal Desativa usuario-->

<div class="modal fade bs-example-modal-sm-ofUser" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">


        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span>
          </button>
          <h4 class="modal-title" id="myModalLabel2">Desativar Usuário</h4>
        </div>

        <form action="<?php echo e($urlUser); ?>/statusUser/<?php echo e($data->user->id); ?>" method="POST">
        <div class="modal-body">

          <div class="form-group">

            <h4>Desativar o Usuário do Funcionário?</h4>


          </div>

        </div>
        <div class="modal-footer">
          <input type="hidden" name="funcionario" value="<?php echo e($data->id); ?>">
          <input type="hidden" name="_method" value="put">
          <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-success">

            OK
          </button>

        </div>

        </form>

    </div>
  </div>
</div>



<!-- Modal Ativar usuario-->

<div class="modal fade bs-example-modal-sm-onUser" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">


        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span>
          </button>
          <h4 class="modal-title" id="myModalLabel2">Ativar Usuário</h4>
        </div>

        <form action="<?php echo e($urlUser); ?>/statusUser/<?php echo e($data->user->id); ?>" method="POST">
        <div class="modal-body">

          <div class="form-group">

            <h4>Ativar o Usuário do Funcionário?</h4>


          </div>

        </div>
        <div class="modal-footer">
          <input type="hidden" name="funcionario" value="<?php echo e($data->id); ?>">
          <input type="hidden" name="_method" value="put">
          <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-success">

            OK
          </button>

        </div>

        </form>

    </div>
  </div>
</div>

<?php endif; ?>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>