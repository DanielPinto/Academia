<?php $__env->startSection('container'); ?>




      <div class="panel panel-default">
        <div class="panel-heading">

          <?php if(Auth::User()->auth == 1): ?>
            <h3 class="panel-title">Administrador</h3>
          <?php elseif(Auth::User()->auth == 2): ?>
            <h3 class="panel-title">Funcionario</h3>
          <?php endif; ?>

        </div>
        <div class="panel-body">
          <p>Nome: <?php echo e(Auth::User()->name); ?></p>
          <p>Email: <?php echo e(Auth::User()->email); ?></p>
        </div>
        <div class="panel-footer">

        </div>
      </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>