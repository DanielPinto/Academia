<!DOCTYPE html>
<html lang="pt-br">

  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Academia VM</title>

    <div style="display:none;">

        <!-- Url  defoult-->
        <?php echo e($urlMain = '/'); ?>

        <?php echo e($srcMain = '/'); ?>


    </div>

    <!-- include files styles css-->
    <?php echo $__env->make('includes.styles', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!--/ include files styles css-->

  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">

<!-- **********************  Navigation sideBar, TopBar, profile Info and FooterSideBar ******************************* -->
        <div class="col-md-3 left_col">
          <div class="left_col scroll-view">

            <div class="navbar nav_title" style="border: 0;">
              <a href="<?php echo e($urlMain); ?>" class="site_title"><i class="fa fa-star"></i> <span>Academia VM</span></a>
            </div>

            <div class="clearfix"></div>

            <!-- menu profile quick info -->
            <?php echo $__env->make('includes.profileInfo', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <!-- /menu profile quick info -->

            <br />

            <!-- sidebar menu -->
            <?php echo $__env->make('includes.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <!-- /sidebar menu -->

            <!-- /menu footer buttons -->
            <?php echo $__env->make('includes.menuFooter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <!-- /menu footer buttons -->

          </div>
        </div>
  <!--/ ********************** / Navigation sideBar, profile Info and FooterSideBar ******************************* -->



      <!-- top navigation -->
        <?php echo $__env->make('includes.topMenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <!-- /top navigation -->

      <div class="right_col" role="main">
        <div class="">
        <!-- content -->
          <?php echo $__env->yieldContent('container'); ?>
        <!-- /content -->
        </div>
      </div>

      <!-- footer content -->
        <?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <!-- /footer content -->

      </div>
    </div>

    <?php echo $__env->make('includes.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  </body>
</html>
