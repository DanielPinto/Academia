<?php $__env->startSection('container'); ?>

  <div style="display:none;">

      <!-- Url  defoult-->
      <?php echo e($urlFunc = '/funcionarios'); ?>

      <?php echo e($srcFunc = ''); ?>


  </div>


  <div class="clearfix"></div>
  <div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
      <div class="x_panel">

        <div class="x_title">
          <h2>Listagem de Funcionário</h2>
          <div class="clearfix"></div>
        </div>


        <div class="x_content">
          <br />
          <table id="datatable-responsive" class="table table-striped jambo_table table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
            <thead>
              <tr class="headings">
                <th>Foto</th>
                <th>CPF</th>
                <th>Nome</th>
                <th>Email</th>
                <th>Telefone</th>
                <th>Mostrar Perfil</th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $funcionario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td>
                    <div class="profile_pic">
                      <?php if($funcionario->foto =='user.png'): ?>
                        <img src="<?php echo e($srcFunc); ?>/images/profiles/<?php echo e($funcionario->foto); ?>" class="avatar" alt="">
                      <?php else: ?>
                        <img src="<?php echo e($srcFunc); ?>/images/profiles/<?php echo e($funcionario->id); ?>/<?php echo e($funcionario->foto); ?>" class="avatar" alt="">

                      <?php endif; ?>
                    </div>
                  </td>
                  <td><?php echo e($funcionario->cpf); ?></td>
                  <td><?php echo e($funcionario->name); ?></td>
                  <td><?php echo e($funcionario->email); ?></td>
                  <td><?php echo e($funcionario->telefone_1); ?> / <?php echo e($funcionario->telefone_2); ?></td>
                  <td><a href="<?php echo e($urlFunc); ?>/<?php echo e($funcionario->id); ?>" class="btn btn-primary btn-xs"><i class="fa fa-user"></i> Perfil </a></td>
                </tr>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
          </table>

        </div>
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>