<!-- Bootstrap -->
<link href="<?php echo e(asset('vendors/bootstrap/dist/css/bootstrap.min.css')); ?>" rel="stylesheet">
<!-- Font Awesome -->
<link href="<?php echo e(asset('vendors/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet">

<!-- Custom Theme Style -->
<link href="<?php echo e(asset('build/css/custom.min.css')); ?>" rel="stylesheet">

<!-- PNotify -->
<link href="<?php echo e(asset('vendors/pnotify/dist/pnotify.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('vendors/pnotify/dist/pnotify.buttons.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('vendors/pnotify/dist/pnotify.nonblock.css')); ?>" rel="stylesheet">


<!-- iCheck -->
<link href="<?php echo e(asset('vendors/iCheck/skins/flat/green.css')); ?>" rel="stylesheet">
<!-- bootstrap-wysiwyg -->
<link href="<?php echo e(asset('vendors/google-code-prettify/bin/prettify.min.css')); ?>" rel="stylesheet">
<!-- Select2 -->
<link href="<?php echo e(asset('vendors/select2/dist/css/select2.min.css')); ?>" rel="stylesheet">
<!-- Switchery -->
<link href="<?php echo e(asset('vendors/switchery/dist/switchery.min.css')); ?>" rel="stylesheet">
<!-- starrr -->
<link href="<?php echo e(asset('vendors/starrr/dist/starrr.css')); ?>" rel="stylesheet">

<!-- Datatables -->
<link href="<?php echo e(asset('vendors/datatables.net-bs/css/dataTables.bootstrap.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('vendors/datatables.net-responsive-bs/css/responsive.bootstrap.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('vendors/datatables.net-buttons-bs/css/buttons.bootstrap.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('vendors/datatables.net-fixedheader-bs/css/fixedHeader.bootstrap.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('vendors/datatables.net-scroller-bs/css/scroller.bootstrap.min.css')); ?>" rel="stylesheet">





<!-- Scripts
OBS: este script é incluso nos styles pois deve ficar head do documento
-->

<script>
    window.Laravel = <?php echo json_encode([
        'csrfToken' => csrf_token(),
    ]); ?>;
</script>
