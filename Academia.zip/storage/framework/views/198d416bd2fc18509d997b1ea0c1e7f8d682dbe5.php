<div style="display:none;">

    <!-- Url  defoult-->
    <?php echo e($urlProfile = ''); ?>

    <?php echo e($srcProfile = ''); ?>


</div>

<div class="profile">
  <div class="profile_pic">

    <?php if(Auth::User()->funcionario->foto == 'user.png'): ?>
      <img src="<?php echo e($srcProfile); ?>/images/profiles/<?php echo e(Auth::User()->funcionario->foto); ?>" alt="..." class="img-circle profile_img">
    <?php else: ?>
      <img src="<?php echo e($srcProfile); ?>/images/profiles/<?php echo e(Auth::User()->funcionario_id); ?>/<?php echo e(Auth::User()->funcionario->foto); ?>" alt="..." class="img-circle profile_img">
    <?php endif; ?>

  </div>
  <div class="profile_info">
    <span>Welcome,</span>
    <h2><?php echo e(Auth::user()->name); ?></h2>
  </div>
</div>
